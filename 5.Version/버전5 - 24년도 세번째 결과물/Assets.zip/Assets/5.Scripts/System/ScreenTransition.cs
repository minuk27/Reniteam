using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum Place
{
    Home_PlayerRoom, Home_LivingRoom, Home_Yard, Town, Voice
}

public class ScreenTransition : MonoBehaviour
{
    [SerializeField] GameObject[] screen;
    [SerializeField] PlayerTeleportation player;
    [SerializeField] CamControl cam;
    [SerializeField] Image blackScreen;
    int nowScreen;
    string[] screenName;

    private void Awake()
    {
        nowScreen = 0;
        screenName = new string[] { "Room", "House", "Yard", "Town", "VoiceTalk"};
        for(int i = 1; i<screen.Length; i++)
        {
            screen[i].SetActive(false);
        }
        screen[0].SetActive(true);
        blackScreen.gameObject.SetActive(false);
    }

    public void changeScreen(Place place, Vector2 pos)
    {
        screen[nowScreen].SetActive(false);
        switch (place)
        {
            case Place.Home_PlayerRoom:
                nowScreen = 0;
                cam.CamMove(Place.Home_PlayerRoom);
                break;
            case Place.Home_LivingRoom:
                nowScreen = 1;
                cam.CamMove(Place.Home_LivingRoom);
                break;
            case Place.Home_Yard:
                nowScreen = 2;
                cam.CamMove(Place.Home_Yard);
                break;
            case Place.Town:
                nowScreen = 3;
                cam.CamMove(Place.Town);
                break;
            case Place.Voice:
                nowScreen = 4;
                cam.CamMove(Place.Voice);
                break;
        }
        StartCoroutine(standbyScreen(nowScreen, pos));
    }

    IEnumerator standbyScreen(int index, Vector2 pos)
    {
        blackScreen.gameObject.SetActive(true);
        blackScreen.GetComponentInChildren<Text>().text = screenName[index];
        yield return new WaitForSeconds(1f);
        blackScreen.gameObject.SetActive(false);
        screen[index].SetActive(true);
        player.playerMove(pos);
    }
}
