using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum UIs
{
    Invectory,
    DialogWindow
}

public class UIManager : MonoBehaviour
{
    [SerializeField] InventoryUI inventory;
    [SerializeField] DialogUI dialogWindow;

    public void Initialize()
    {
        inventory.gameObject.SetActive(false);
        dialogWindow.gameObject.SetActive(false);
    }

    public void ActiveUI(UIs cui) //������ uiȰ��
    {
        switch (cui)
        {
            case UIs.Invectory:
                inventory.gameObject.SetActive(true);
                break;
            case UIs.DialogWindow:
                dialogWindow.gameObject.SetActive(true);
                break;
        }
    }

    public void InActiveUI(UIs cui) //������ ui��Ȱ��
    {
        switch (cui)
        {
            case UIs.Invectory:
                inventory.gameObject.SetActive(false);
                break;
            case UIs.DialogWindow:
                dialogWindow.gameObject.SetActive(false);
                break;
        }
    }


    public void startTalkNPC(int npc)
    {
        if (GameManager.Manager.GetSetTalkManager.GetIsQuest(npc)) 
        {
            //����Ʈ������ Ȱ��ȭ
        }
        string talkData = GameManager.Manager.GetSetTalkManager.GetTalk(npc);
        dialogWindow.SetText(talkData);
    }

    public void startTalk(string text)
    {
        dialogWindow.SetText(text);
    }

    public bool isEndTalk { get { return dialogWindow.isEndTalk; } }

    public void endTalk()
    {
        dialogWindow.ActiveFalse();
    }

    public DialogUI getVoiceWindow()
    {
        return dialogWindow.GetComponent<DialogUI>();
    }
}
