using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    private static GameManager manager;
    public static GameManager Manager
    {
        get
        {
            if (manager == null)
            {
                return null;
            }
            return manager;
        }
    }

    //private EventManager eventManager; //�̺�Ʈ �Ŵ���
    //private SceneChangeManager sceneManager; //����ȯ �Ŵ���
    private QuestManager questManager; //����Ʈ �Ŵ���
    private TalkManager talkManager; //��ȭ �Ŵ���    
    private StoryManager storyManager; //���丮�Ŵ���
    private STTManager sttManager; //stt�Ŵ���

    [SerializeField] UIManager uiManager; //ui�Ŵ���
    [SerializeField] ScreenTransition screenTransition;


    private void Awake()
    {
        if (manager)
        {
            DestroyImmediate(this.gameObject);
            return;
        }
        manager = this;
        DontDestroyOnLoad(this.gameObject);

        ManagerInstance();
        InitializeManagers();
    }

    private void ManagerInstance()
    {
        //eventManager = new EventManager();
        //sceneManager = new SceneChangeManager();
        talkManager = new TalkManager();        
        questManager = new QuestManager();
        sttManager = new STTManager();
        storyManager = new StoryManager();
    }

    private void InitializeManagers()
    {
        talkManager.Initialize();
        questManager.Initialize();
        sttManager.Initialize();
        storyManager.Initialize();
        uiManager.Initialize();
    }

    //public EventManager GetSetEventManager { get { return eventManager; } }
    //public SceneChangeManager GetSceneManager { get { return sceneManager; } }

    public TalkManager GetSetTalkManager { get { return talkManager; } }

    public STTManager GetSttManager { get { return sttManager; } }

    public StoryManager GetStoryManager { get { return storyManager; } }

    public QuestManager GetQuestManager { get { return questManager; } }

    public UIManager GetUIManager { get { return uiManager; } }

    public ScreenTransition GetScreenTransition { get { return screenTransition; } }
}