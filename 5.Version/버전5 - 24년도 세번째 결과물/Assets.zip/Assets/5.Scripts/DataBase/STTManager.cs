using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class STTManager : MonoBehaviour
{
    Dictionary<int, VoiceDB> voiceDictionary;
    private Voice voice;
    private int voiceIndex;
    private int questionIndex;
    public void Initialize()
    {
        voiceIndex = 0;
        questionIndex = 0;
        voiceDictionary = new Dictionary<int, VoiceDB>();
        voice = Resources.Load<GameObject>("Voice").GetComponent<Voice>();
        for (int i = 0; i < voice.voiceDB.Count; i++)
        {
            voiceDictionary.Add(voice.voiceDB[i].index, voice.voiceDB[i]);
        }
    }

    public string getQuestion()
    {
        string returnText = null;
        if(voiceDictionary[voiceIndex].question.Length > questionIndex)
        {
            returnText = voiceDictionary[voiceIndex].question[questionIndex];
            questionIndex += 1;
        }
        return returnText;
    }

    public bool interrogate(string[] answer)
    {
        bool isCorrect = false;
        for (int i = 0; i < voiceDictionary[voiceIndex].answer.Length; i++)
        {
            for(int j = 0; j< answer.Length; j++)
            {
                if (voiceDictionary[voiceIndex].answer[i].Equals(answer[j].Trim()))
                {
                    isCorrect = true;
                    break;
                }
            }
            if (!isCorrect)
            {
                break;
            }
        }

        voiceIndex += 1;
        questionIndex = 0;

        return isCorrect;
    }
}