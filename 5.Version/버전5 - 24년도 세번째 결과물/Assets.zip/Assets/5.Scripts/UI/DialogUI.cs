using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DialogUI : MonoBehaviour
{
    [SerializeField] GameObject talkContents;
    [SerializeField] Text talkText;
    [SerializeField] GameObject talkArrow;
    [SerializeField] GameObject selectWindow;
    private bool endTalk;
    private bool isQuest;

    private void Awake()
    {
        ActiveFalse();
    }

    public void ActiveFalse()
    {
        talkContents.SetActive(false);
        talkArrow.SetActive(false);
        selectWindow.SetActive(false);
        endTalk = false;
        isQuest = false;
    }

    public void SetText(string text)
    {
        endTalk = false;
        StartCoroutine(writeText(text));
    }

    IEnumerator writeText(string text)
    {
        talkContents.SetActive(true);
        talkText.text = "";
        foreach (char t in text)
        {
            talkText.text += t;
            yield return new WaitForSeconds(0.05f);
        }
        endTalk = true;
    }

    public bool isEndTalk { get { return endTalk; } }
}
