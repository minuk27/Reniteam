using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerTeleportation : MonoBehaviour
{
    private bool isTeleprot;
    private float nowTime;
    private float delay;
    private Place nowPlace;

    // Start is called before the first frame update
    void Start()
    {
        isTeleprot = true;
        delay = 0.5f;
        nowTime = 0f;
    }

    // Update is called once per frame
    void Update()
    {
        if (isTeleprot)
            return;
        if (nowTime < delay)
        {
            nowTime += Time.deltaTime;
        }
        else
            isTeleprot = true;
    }

    public void playerMove(Vector2 pos)
    {
        this.gameObject.transform.position = pos;
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "portal" && isTeleprot)
        {
            Place place = collision.gameObject.GetComponent<Portal>().getPlace;
            Vector2 pos = collision.gameObject.GetComponent<Portal>().getPostion;
            if (Input.GetKey(KeyCode.UpArrow))
            {
                teleFunction(place, pos);
                nowPlace = place;
            }
            else if(Input.GetKey(KeyCode.D) && nowPlace == Place.Voice)
            {
                teleFunction(place, pos);
                nowPlace = place;
            }
        }
    }

    private void teleFunction(Place place, Vector2 pos)
    {
        nowTime = 0f;
        isTeleprot = false;
        GameManager.Manager.GetScreenTransition.changeScreen(place, pos);
    }
}
