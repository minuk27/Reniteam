using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portal : MonoBehaviour
{
    [SerializeField]
    private GameObject position;
    [SerializeField]
    private Place place;
    

    public Vector2 getPostion { get { return position.transform.position; } }
    public Place getPlace { get { return place; } }
}
