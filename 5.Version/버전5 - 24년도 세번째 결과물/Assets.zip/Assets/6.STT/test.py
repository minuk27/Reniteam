import json
import requests
import os
from mecab import MeCab

mecab = MeCab()

def stt(Id, Server, audio_file_path):
    lang = "Kor"
    url = "https://naveropenapi.apigw.ntruss.com/recog/v1/stt?lang=" + lang

    try:
        with open(audio_file_path, 'rb') as audio_file:
            headers = {
                "X-NCP-APIGW-API-KEY-ID": Id,
                "X-NCP-APIGW-API-KEY": Server,
                "Content-Type": "application/octet-stream"
            }

            response = requests.post(url, data=audio_file, headers=headers)

            rescode = response.status_code

            if rescode == 200:
                print(response.text)
                return response.text
            else:
                print("Error : " + response.text)
                return None

    except FileNotFoundError:
        print(f"Error: File not found at path {audio_file_path}")
        return None

def process_text(text):
    # 텍스트를 MeCab을 사용하여 토큰화합니다.
    tokens = mecab.pos(text)
    
    # 토큰 중 명사만 추출하여 리스트에 저장합니다.
    nouns = [token[0] for token in tokens if token[1] == 'NNG']

    return nouns

if __name__ == "__main__":
    Id = "s5cnwsoc86"
    Server = "A1AIG817u9N7svAaqBwuEqqiI5y2wKLfjROagNpo"
    audio_file_path = 'C:/UnityGame/CapStone/Assets/8.Data/test.wav'  # Change this to the correct path for your audio file

    # Call the STT function
    Text = stt(Id, Server, audio_file_path)

    if Text:
        # 텍스트를 처리하고 명사를 추출합니다.
        nouns = process_text(Text)

        # 추출된 명사 리스트 출력
        print("추출된 명사:", nouns)

        output_folder = "C:/UnityGame/CapStone/Assets/8.Data"
        output_file_path = os.path.join(output_folder, "nouns.json")
        
        # 파일로 저장 예시
        with open(output_file_path, "w", encoding="utf-8") as file:
            file.write("\n".join(nouns))
