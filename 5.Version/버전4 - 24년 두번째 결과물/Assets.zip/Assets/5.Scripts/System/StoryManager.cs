using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum Story
{

}

public class StoryManager : MonoBehaviour
{
    private List<int> storySteps;
    private int nowStep;

    public void Initialize()
    {

    }
}
