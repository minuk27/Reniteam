using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum QuestTarget
{
    npc, item
}

public class QuestManager : MonoBehaviour
{
    public Dictionary<int, Quest> questDictionary;
    private QuestDB questDB;
    private bool isQuest;

    private int questID;
    private QuestTarget questTarget;

    public void Initialize()
    {
        questDictionary = new Dictionary<int, Quest>();
        questDB = Resources.Load<GameObject>("Quest").GetComponent<QuestDB>();
        for (int i = 0; i < questDB.quest.Count; i++)
        {
            questDictionary.Add(questDB.quest[i].questID, questDB.quest[i]);
        }
    }

    public void QuestAccept(int id, QuestTarget qtarget)
    {
        questID = id; questTarget = qtarget;
    }

    public void IsQuestSuccess(int id, QuestTarget qtarget)
    {
        if(questID == id && questTarget == qtarget)
        {
            //����Ʈ����
            //����Ʈdb���� �ش� ����Ʈ�� ���丮�� ������ ��ġ���� �Ǵ�
            //���丮�� ����
        }
    }
}
