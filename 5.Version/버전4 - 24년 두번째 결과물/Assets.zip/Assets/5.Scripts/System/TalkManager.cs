using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TalkManager : MonoBehaviour
{
    Dictionary<int, Dialog> talkDictionary;
    private DialogDB di;

    public void Initialize()
    {
        talkDictionary = new Dictionary<int, Dialog>();
        di = Resources.Load<GameObject>("NPCDialogDB").GetComponent<DialogDB>();
        di.Setting();
        for(int i = 0; i<di.npcDialogDB.Count; i++)
        {
            talkDictionary.Add(di.npcDialogDB[i].id, di.npcDialogDB[i]);
        }
    }

    public string GetTalk(int id)
    {
        string talk = talkDictionary[id].speechDB[talkDictionary[id].startSpeech];
        talkDictionary[id].startSpeech += talkDictionary[id].startSpeech == talkDictionary[id].speechIndex[talkDictionary[id].endSpeech] ? 0 : 1;
        return talk;
    }

    public bool GetIsQuest(int id)
    {
        if (talkDictionary[id].questIndex.Count > 0)
            return talkDictionary[id].questIndex[talkDictionary[id].startQuest] == talkDictionary[id].startSpeech ? true : false;
        else
            return false;
    }

    public void NextTalk(int id)
    {
        talkDictionary[id].startSpeech += 1;
        talkDictionary[id].endSpeech += 1;
        talkDictionary[id].startQuest += 1;
    }
}