using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public enum UIs
{
    Invectory,
    ChatWindow,
    VoiceWindow
}

public class UIManager : MonoBehaviour
{
    [SerializeField]
    private GameObject inventoryWindow;    
    [SerializeField]
    private GameObject voiceWindow;

    private Inventory inventory;
    [SerializeField]
    private TalkUI talkUI;
    

    public void Initialize()
    {
        inventory = inventoryWindow.GetComponent<Inventory>();
        
        talkUI.ActiveFalse();
        inventoryWindow.SetActive(false);
        voiceWindow.SetActive(false);
    }

    public void ActiveUI(UIs cui) //������ uiȰ��
    {
        switch (cui)
        {
            case UIs.Invectory:
                inventoryWindow.SetActive(true);
                break;
            case UIs.VoiceWindow:
                voiceWindow.SetActive(true);
                break;
        }
    }

    public void InActiveUI(UIs cui) //������ ui��Ȱ��
    {
        switch (cui)
        {
            case UIs.Invectory:
                inventoryWindow.SetActive(false);
                break;
            case UIs.VoiceWindow:
                voiceWindow.SetActive(false);
                break;
        }
    }


    public void StartTalk(int npc)
    {
        if (GameManager.Manager.GetSetTalkManager.GetIsQuest(npc)) 
        {
            talkUI.ActiveQuest();
        }
        string talkData = GameManager.Manager.GetSetTalkManager.GetTalk(npc);
        talkUI.SetText(talkData);
    }

    public bool IsEndTalk()
    {
        return talkUI.IsEndTalk;
    }

    public void EndTalk()
    {
        talkUI.ActiveFalse();
    }

    public JsonTest getVoiceWindow()
    {
        return voiceWindow.GetComponent<JsonTest>();
    }
}
